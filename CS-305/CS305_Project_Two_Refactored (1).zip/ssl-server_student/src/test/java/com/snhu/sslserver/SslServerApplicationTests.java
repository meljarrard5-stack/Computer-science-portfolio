package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SslServerApplicationTests {
    @Test void matchesPublishedSha256Vectors() {
        assertEquals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", ChecksumService.sha256(""));
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", ChecksumService.sha256("abc"));
    }
    @Test void detectsChangedDataAndMalformedChecksums() {
        String digest = ChecksumService.sha256(HashController.DATA);
        assertTrue(ChecksumService.matches(HashController.DATA, digest));
        assertFalse(ChecksumService.matches(HashController.DATA + "!", digest));
        assertFalse(ChecksumService.matches(HashController.DATA, "invalid"));
        assertFalse(ChecksumService.matches(HashController.DATA, null));
        assertFalse(ChecksumService.matches(HashController.DATA, "0".repeat(64)));
    }
    @Test void endpointVerifiesExpectedDemonstrationData() {
        var response = new HashController().hash();
        assertEquals(200, response.getStatusCode().value());
        assertEquals(true, response.getBody().get("verified"));
        assertEquals("Melanie Jarrard", response.getBody().get("name"));
    }
}
