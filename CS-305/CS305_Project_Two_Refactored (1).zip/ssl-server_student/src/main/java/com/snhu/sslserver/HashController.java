package com.snhu.sslserver;

import java.util.Map;
import org.springframework.http.CacheControl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HashController {
    // Public demonstration data only. Do not put financial information in URLs.
    public static final String DATA =
            "Melanie Jarrard | Artemis Financial | CS305 Project Two | 2026-10-24 | AF-MJ-8F29C4";
    private static final String EXPECTED = "1279ed099f4e52552208887cde53bf03419f9f9a33c9334811752a7fcd98b629";

    @GetMapping(value = "/hash", produces = "application/json")
    public ResponseEntity<Map<String, Object>> hash() {
        return ResponseEntity.ok().cacheControl(CacheControl.noStore())
                .header("X-Content-Type-Options", "nosniff")
                .body(Map.of("name", "Melanie Jarrard", "data", DATA,
                        "algorithm", "SHA-256", "checksum", ChecksumService.sha256(DATA),
                        "expectedChecksum", EXPECTED,
                        "verified", ChecksumService.matches(DATA, EXPECTED)));
    }
}
