package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

/** Uses the JDK provider rather than a custom cryptographic implementation. */
public final class ChecksumService {
    private ChecksumService() { }

    public static String sha256(String data) {
        try {
            // Each request has its own digest instance; MessageDigest is mutable.
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(data.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("Required hash algorithm unavailable", ex);
        }
    }

    public static boolean matches(String data, String expectedHex) {
        if (expectedHex == null || !expectedHex.matches("[0-9a-fA-F]{64}")) {
            return false;
        }
        return MessageDigest.isEqual(HexFormat.of().parseHex(sha256(data)),
                HexFormat.of().parseHex(expectedHex));
    }
}
