# Artemis Financial CS 305 Project Two

Prepared for Melanie Jarrard. This refactors the supplied ssl-server_student project.
Requires JDK 17 or newer. Use an Eclipse release supporting Java 17 and Maven.

## Run on Windows in Eclipse

1. Extract the ZIP to a normal folder. In Eclipse choose File > Import > Maven > Existing Maven Projects, select this folder containing pom.xml, and Finish.
2. Set the project's JRE to JDK 17 or newer. Right-click the project > Maven > Update Project.
3. Open Run > Run Configurations > Java Application. Create a configuration for com.snhu.sslserver.SslServerApplication. In Environment add ARTEMIS_KEYSTORE_PASSWORD with value ArtemisLocalDemo2026. In Arguments set Working directory to the project folder containing pom.xml. Run.
4. Open https://localhost:8443/hash. The JSON must show Melanie Jarrard, the unique data string, two equal SHA-256 values, and verified: true. Use browser pretty printing if available.
5. If it fails, send the Eclipse Console output and your Java version.

The included PKCS12 private key and its published password are for this localhost course demonstration ONLY. They are not production credentials. The application binds only to the local loopback interface. Replace the key and use a CA-issued certificate and protected secret storage before any real deployment.

## Generate your own certificate using Keytool from Eclipse

The rubric requests Keytool in Eclipse. Regenerate the included demonstration certificate yourself so your screenshot documents your work. Stop the application first. Open the Eclipse Terminal view in the project folder (or use a JDK Keytool External Tools configuration with the project folder as working directory). Rename/delete ONLY certificates/artemis-local.p12 before generating a new key. Run:

    keytool -genkeypair -alias artemis-local -keyalg RSA -keysize 3072 -sigalg SHA256withRSA -validity 365 -dname "CN=localhost, OU=CS305, O=Artemis Financial, L=Mission Viejo, ST=California, C=US" -ext "SAN=dns:localhost,ip:127.0.0.1" -ext "EKU=serverAuth" -storetype PKCS12 -keystore certificates/artemis-local.p12

Choose a password and set ARTEMIS_KEYSTORE_PASSWORD in your Run Configuration to that password. Export the public certificate:

    keytool -exportcert -rfc -alias artemis-local -keystore certificates/artemis-local.p12 -file certificates/artemis-local.cer
    keytool -printcert -file certificates/artemis-local.cer

Capture the CER file open in Windows Certificate Viewer, showing subject, issuer, and validity. Never screenshot a password or private-key contents.

## Browser trust for the secure-page screenshot

A self-signed certificate is not automatically trusted. Clicking through a warning does not make the connection authenticated. For this local course demo, inspect the generated certificate and fingerprint, then import ONLY certificates/artemis-local.cer using Windows Certificate Import Wizard > Current User > Trusted Root Certification Authorities. Do not import the P12. Restart Chrome/Edge and revisit https://localhost:8443/hash. Open the site information control and capture both the URL and the connection security status. If trust is managed by your organization, ask your instructor how to document the self-signed demo. Remove this exact demonstration certificate from your user trust store when finished. Regenerating the key requires trusting the newly exported CER again.

## Tests and dependency scan

In Eclipse, Run As > Maven build with goals:

    clean test

Capture BUILD SUCCESS and the test summary. Then run goals:

    verify

Dependency-Check 13.0.0 is bound to verify; it writes target/dependency-check-report.html and JSON. Set NVD_API_KEY in the Maven run configuration environment if you have your NVD key. Never put the key in the POM or report. The initial database update can take time. Keep network access enabled. A failed/incomplete update is not a passing scan. The scan fails for errors or CVSS >= 7; review ALL findings, including lower severity, for applicability. Do not suppress real vulnerabilities to achieve a green build. No suppressions are preconfigured.

Capture the report overview with scan date and findings. Send the actual HTML report so we can review findings, fix applicable issues, and complete the report honestly. Compare results with the starter dependency tree if documenting before/after findings. Dependency-Check examines dependencies; it does not prove custom Java code is vulnerability-free.

## Required evidence to finish the report

A. CER file in Certificate Viewer (and preferably Eclipse Keytool generation/export console).
B. Browser /hash output showing your name, data, checksums, verified true.
C. Browser URL and site information showing a trusted HTTPS connection.
D. Eclipse Maven successful test/build output.
E. Completed Dependency-Check report, including any findings/remediation.

The report includes the supplied browser, certificate, execution, and dependency scan evidence. The same successful execution screenshot can support functional and secondary testing where appropriate.

## Files changed

pom.xml: Spring Boot 4.1.2, Java 17, minimal web MVC dependency, Dependency-Check 13.0.0 with HTML/JSON output and failure thresholds.
src/main/java/com/snhu/sslserver/ChecksumService.java: SHA-256 UTF-8 hashing and checksum comparison.
src/main/java/com/snhu/sslserver/HashController.java: read-only /hash demo with independent expected checksum.
src/main/resources/application.properties: HTTPS on 8443, PKCS12, environment password, TLS 1.2/1.3, generic errors.
src/test/java/com/snhu/sslserver/SslServerApplicationTests.java: published vectors, altered/malformed digest cases, endpoint result.
certificates/: demonstration private keystore and exported public CER.

## Limitations

This fixed-string endpoint demonstrates the rubric's checksum requirement; it is not a financial-file upload or storage service. Real file verification must hash the exact received file bytes and compare with an expected digest obtained through an authenticated channel (or verify a digital signature). An attacker who can replace both file and checksum can defeat a bare hash. This project adds no client authentication, authorization, database, or real financial data. TLS certificates do not supply application authorization.

## Verified results

The prepared source passed three tests and packaged successfully. The user ran the application in Eclipse and verified /hash in Chrome using a trusted certificate. Eclipse Maven verify completed on October 24, 2026 with BUILD SUCCESS. Dependency-Check scanned 39 dependencies (17 unique), reporting 0 vulnerabilities and 0 suppressions. OSS Index was disabled because credentials were absent; this limits scanner coverage. The successful HTML report is in verification/dependency-check-report.html. Earlier preparation logs documenting a blocked scan are retained as historical logs, not the final scan outcome.

The report now includes supplied screenshots. Keytool generation in Eclipse itself is not documented by those screenshots. For literal compliance with that rubric step, follow the Keytool instructions above, then recapture the exported CER and browser evidence if the key changes.
