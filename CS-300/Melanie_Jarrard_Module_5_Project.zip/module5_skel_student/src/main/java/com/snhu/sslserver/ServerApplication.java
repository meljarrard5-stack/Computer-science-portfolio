package com.snhu.sslserver;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;



@SpringBootApplication
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}

@RestController
class ServerController {
    // Author: Melanie Jarrard
    @RequestMapping(value = "/hash", method = RequestMethod.GET, produces = "text/html")
    public String myHash() throws NoSuchAlgorithmException {
        String data = "Hello Melanie Jarrard!";
        String algorithm = "SHA-256";
        MessageDigest digest = MessageDigest.getInstance(algorithm);
        byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
        String checksum = bytesToHex(hash);

        return "<!DOCTYPE html><html><head><title>Checksum Verification</title></head><body>"
                + "<p>data: " + data + "</p>"
                + "<p>algorithm: " + algorithm + "</p>"
                + "<p>checksum: " + checksum + "</p>"
                + "</body></html>";
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder hex = new StringBuilder(bytes.length * 2);
        for (byte value : bytes) {
            hex.append(String.format("%02x", value & 0xff));
        }
        return hex.toString();
    }
}
